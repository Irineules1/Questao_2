﻿using System;
using System.Collections.Generic;


public class PilhaDePecas
{
    private Stack<Peca> pilha;

    public PilhaDePecas()
    {
        pilha = new Stack<Peca>();
    }

    // Adicionar peça à pilha
    public void Empilhar(Peca peca)
    {
        pilha.Push(peca);
    }

    // Remover e retornar a peça do topo da pilha
    public Peca Desempilhar()
    {
        return pilha.Count > 0 ? pilha.Pop() : null;
    }

    // Substituir uma peça velha por uma nova
    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        Stack<Peca> pecasTemp = new Stack<Peca>(); // Pilha temporária para armazenar as peças retiradas

        // Remover as peças até encontrar a peça velha
        while (pilha.Count > 0)
        {
            Peca pecaAtual = Desempilhar();
            if (pecaAtual.Nome == nomePecaVelha)
            {
                // Encontrou a peça velha, agora substitui pela nova
                pecasTemp.Push(new Peca(nomePecaNova));
                break;
            }
            else
            {
                // Armazena as peças temporariamente
                pecasTemp.Push(pecaAtual);
            }
        }

        // Recolocar as peças de volta na pilha
        while (pecasTemp.Count > 0)
        {
            Empilhar(pecasTemp.Pop());
        }
    }

    // Exibir todas as peças na pilha
    public void MostrarPilha()
    {
        Console.WriteLine("Estado atual da pilha:");
        foreach (var peca in pilha)
        {
            Console.WriteLine(peca);
        }
    }
}