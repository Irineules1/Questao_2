﻿using System;

class Programa
{
    static void Main(string[] args)
    {
        Montador montador = new Montador();

        // Monta o ventilador com as peças na ordem correta
        montador.MontarVentilador();

        Console.WriteLine("Pilha original:");
        montador.ExibirPilha();

        // Simula a substituição da peça "Hélice" por "Hélice Nova"
        Console.WriteLine("\nSubstituindo a peça 'Hélice' por 'Hélice Nova'...");
        montador.SubstituirPeca("Hélice", "Hélice Nova");

        Console.WriteLine("\nPilha após a substituição:");
        montador.ExibirPilha();
    }
}