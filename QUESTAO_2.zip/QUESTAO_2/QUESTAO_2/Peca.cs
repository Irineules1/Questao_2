﻿public class Peca
{
    public string Nome { get; set; }

    public Peca(string nome)
    {
        Nome = nome;
    }

    public override string ToString()
    {
        return Nome;
    }
}