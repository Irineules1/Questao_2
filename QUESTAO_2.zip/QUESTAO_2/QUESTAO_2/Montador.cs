﻿public class Montador
{
    private PilhaDePecas pilhaDePecas;

    public Montador()
    {
        pilhaDePecas = new PilhaDePecas();
    }

    // Montar o ventilador empilhando as peças na ordem correta
    public void MontarVentilador()
    {
        pilhaDePecas.Empilhar(new Peca("Cúpula de Vidro"));
        pilhaDePecas.Empilhar(new Peca("Lâmpada"));
        pilhaDePecas.Empilhar(new Peca("Hélice"));
        pilhaDePecas.Empilhar(new Peca("Suporte"));
    }

    // Substituir uma peça do ventilador
    public void SubstituirPeca(string nomePecaVelha, string nomePecaNova)
    {
        pilhaDePecas.SubstituirPeca(nomePecaVelha, nomePecaNova);
    }

    // Mostrar o estado atual da pilha
    public void ExibirPilha()
    {
        pilhaDePecas.MostrarPilha();
    }
}